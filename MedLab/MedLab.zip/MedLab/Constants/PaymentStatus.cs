﻿namespace MedLab.Constants
{
    public enum PaymentStatus
    {
        PAID,
        PENDING,
        FAILED
    }

}
