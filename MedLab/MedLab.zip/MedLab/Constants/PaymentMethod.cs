﻿namespace MedLab.Constants
{
    public enum PaymentMethod
    {
        CREDITCARD,
        DEBITCARD,
        CASH,
        NETBANKING
    }

}
