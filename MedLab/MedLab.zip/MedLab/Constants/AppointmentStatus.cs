﻿namespace MedLab.Constants
{
    public enum AppointmentStatus
    {
        SCHEDULED,
        COMPLETED,
        CANCELLED
    }
}
