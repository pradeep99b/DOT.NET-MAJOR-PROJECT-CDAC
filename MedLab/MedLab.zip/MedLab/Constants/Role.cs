﻿namespace MedLab.Constants
{
    public enum Role
    {
        ADMIN=1,
        LABASSISTANT,
        PATIENT
    }

}
